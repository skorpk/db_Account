USE ACCOTFOMS2011
GO
SELECT p.FAM,p.Im,p.DR,p.ENP,CONVERT(DATE,c.DATE_1,120) AS DateBeg,CONVERT(DATE,c.DATE_2,120) AS DateEnd
--INTO tmp_EKO_Victor
FROM dbo.t_FilesR f INNER JOIN dbo.t_Accounts a ON
			f.id=a.id_FileR
				 INNER JOIN dbo.t_Pacients p ON
			a.id=p.id_Account
				INNER JOIN t_Cases c ON
			p.id=c.id_Pacient              
				 INNER JOIN (VALUES ('45000','431',90,'774781'),('45000','431',282,'774795'),('45000','431',1482,'774795'),('45000','592',1023,'774781'),('45000','752',56,'774864'),('45000','752',205,'774781'),
									('45000','752',910,'774781'),('45000','752',2159,'774781'),('45000','752',2162,'774781'),('63000','70134',143,'640971'),('63000','70434',274,'640971'))
									v(OKATO,Account,N_ZAP,CodeM) ON
			a.C_OKATO1=v.OKATO
			AND a.NSCHET=v.account
			AND p.N_ZAP=v.n_zap
WHERE a.YEAR=2017